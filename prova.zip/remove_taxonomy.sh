#!/bin/bash
INC=1000000
rm -rf out
regex='^"(..)", (.*)$'
while IFS='' read -r line || [[ -n "$line" ]]; do
    if [ "$line" != "" ]; then
        line=${line,,}
        if [[ $line =~ $regex ]]; then
echo ""
           country=${BASH_REMATCH[1]}
           server=${BASH_REMATCH[2]}
           echo "country=$country, server=$server"
           command="psql -h $server -p 5432 -U je_${country}_rw -w je_${country} -c \"copy (select min(id),max(id),max(id)-min(id) from advert) to stdout with (format csv)\""
           result=`bash -c "$command"`
           split_regex='^([0-9]+),([0-9]+),([0-9]+).*$'
           if [[ $result =~ $split_regex ]]; then
              min=$(( ${BASH_REMATCH[1]} ))
              max=$(( ${BASH_REMATCH[2]} ))
              tot=$(( ${BASH_REMATCH[3]} ))
              echo "min=$min, max=$max, tot=$tot"
           fi
           current=$min
           while [ $current -le $max ]; do
             bound=$(( $current + $INC ))
             clause="BETWEEN $current AND $(( $bound - 1  ))"
             query="UPDATE advert SET taxonomy_category=null, taxonomy_confidence=null WHERE id $clause"
             command="psql -h $server -p 5432 -U je_${country}_rw -w je_${country} -c '$query'"
             echo $command
             bash -c "$command >>remove_taxonomy.log"

             current=$bound
           done
echo ""
echo ""
        fi
    fi
done < not_english_countries.txt

