#!/bin/bash
rm -rf out
regex='^"(..)", (.*)$'
while IFS='' read -r line || [[ -n "$line" ]]; do
    if [ "$line" != "" ]; then
        line=${line,,}
        if [[ $line =~ $regex ]]; then
           country=${BASH_REMATCH[1]}
           server=${BASH_REMATCH[2]}
           echo "country=$country, server=$server"
           command="psql -h $server -p 5432 -U je_${country}_rw -w je_${country} -c \"copy (select '${country}' as country, id, substring(substring(email,'@.*$') from 2) as emaildomain, doubleoptindatetime as jobseekerconfirmationdate from jobseeker_registered) to stdout with (format csv, quote '\\\"', force_quote (country,emaildomain))\" | grep ."
         bash -c "$command >>out"
        fi
    fi
done < cnt

